ReadMe:

GAME-OVER SFU
The game is based on free roaming while completing small tasks SFU. The tasks involve making decision in certain situations. Making the right decision will lead to you being able to continue the game and finsih all 5 tasks, or making a wrong choice will cause the game to be over and you starting again.

To start, you can roam around SFU freely and look for the tasks based on the stories made. There are 5 stories leading to 5 paths around SFU and each ends with a task. Finishing the 5 tasks will result in victory.
Note: the game represents real-world locations on SFU.

The game involves pressing one of 4 options to navigatge the map:
1. Go North
2. Go East
3. Go South
4. Go West

At tasks, the player will have different options to choose from. choosing wisely will lead to a continued game or else it will result in game over, starting the game all over again.


The medium to be used is AndroidStudio and the phone for the emulator is Pixel 2. Minmimum SDK is 4.1 JellyBean whereas minmimum Java requirement is Java 8.0.

HAVE FUN!

